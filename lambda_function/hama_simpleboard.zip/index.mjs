import { DynamoDB } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocument } from '@aws-sdk/lib-dynamodb';

const dynamo = DynamoDBDocument.from(new DynamoDB());

export const handler = async (event) => {
    let body;
    let statusCode = '200';
    const headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
    };

    console.log('Received event:', JSON.stringify(event));  // 요청 데이터 로그 출력

    try {
        switch (event.httpMethod) {
            case 'DELETE':
                // URL 쿼리 파라미터에서 article_id 추출
                const article_id = event.queryStringParameters?.article_id;

                if (!article_id) {
                    throw new Error("삭제할 article_id가 제공되지 않았습니다.");
                }

                console.log('Deleting article with ID:', article_id);

                // DynamoDB에서 항목 삭제
                body = await dynamo.delete({
                    TableName: "hama-web-Dynamo",
                    Key: { article_id }  // 삭제할 게시물의 article_id
                });

                console.log('Delete operation succeeded:', body);
                break;

            case 'GET':
                const title = event.queryStringParameters?.title;
                if (title) {
                    // GSI를 사용하여 title에 해당하는 게시물 반환
                    body = await dynamo.query({
                        TableName: "hama-web-Dynamo",
                        IndexName: "simpleboard-title-index",  // GSI 이름을 명시
                        KeyConditionExpression: 'title = :title',  // title로 항목을 조회
                        ExpressionAttributeValues: {
                            ':title': title
                        }
                    });
                } else {
                    // title이 존재하는 항목만 반환
                    body = await dynamo.scan({
                        TableName: "hama-web-Dynamo",
                        FilterExpression: "attribute_exists(title)"  // title이 존재하는 항목만 필터링
                    });
                }
                console.log('GET operation succeeded:', body);
                break;

            case 'POST':
                // 요청 본문에서 Item만 추출하고 TableName은 Lambda에서 명시적으로 설정
                const postBody = JSON.parse(event.body).Item;
                console.log('Parsed POST body:', postBody);  // 요청 본문 로그 출력
                body = await dynamo.put({
                    TableName: "hama-web-Dynamo",  // DynamoDB 테이블 이름을 명시
                    Item: postBody  // Item 데이터만 삽입
                });
                console.log('Put operation succeeded:', body);  // DynamoDB 성공 로그 출력
                break;

            case 'PUT':
                body = await dynamo.update(JSON.parse(event.body));
                console.log('Update operation succeeded:', body);
                break;

            default:
                throw new Error(`Unsupported method "${event.httpMethod}"`);
        }
    } catch (err) {
        statusCode = '400';  // 오류 발생 시 상태 코드 400으로 설정
        body = JSON.stringify({ message: err.message });  // 명확한 오류 메시지 반환
        console.error('Error:', err);  // 오류 로그 출력
    } finally {
        return {
            statusCode,
            body: JSON.stringify(body),  // 응답 본문을 JSON 문자열로 변환
            headers,
        };
    }
};
