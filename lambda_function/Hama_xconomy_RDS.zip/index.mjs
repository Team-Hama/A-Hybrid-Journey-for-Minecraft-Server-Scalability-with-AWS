import mysql from 'mysql2/promise';

const RDS_HOST = process.env.RDS_HOST;
const DB_USERNAME = process.env.DB_USERNAME;
const DB_PASSWORD = process.env.DB_PASSWORD;
const DB_NAME = process.env.DB_NAME;

export const handler = async (event) => {
    let connection;

    try {
        // MySQL에 연결
        connection = await mysql.createConnection({
            host: RDS_HOST,
            user: DB_USERNAME,
            password: DB_PASSWORD,
            database: DB_NAME
        });

        // Lambda 요청에서 minecraft_username 가져오기
        const minecraft_username = JSON.parse(event.body).minecraft_username;

        // SQL 쿼리
        const [rows] = await connection.execute("SELECT balance FROM xconomy WHERE player = ?", [minecraft_username]);

        if (rows.length > 0) {
            const balance = rows[0].balance;
            return {
                statusCode: 200,
                headers: {
                    'Access-Control-Allow-Origin': '*',  // 모든 출처 허용
                    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
                    'Access-Control-Allow-Headers': 'Content-Type'
                },
                body: JSON.stringify({ balance: balance })
            };
        } else {
            return {
                statusCode: 404,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
                    'Access-Control-Allow-Headers': 'Content-Type'
                },
                body: JSON.stringify({ error: 'User not found' })
            };
        }
    } catch (error) {
        return {
            statusCode: 500,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
                'Access-Control-Allow-Headers': 'Content-Type'
            },
            body: JSON.stringify({ error: 'Internal Server Error', details: error.message })
        };
    } finally {
        if (connection) {
            await connection.end(); // 연결 종료
        }
    }
};
