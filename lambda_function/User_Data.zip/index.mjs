import { DynamoDB } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocument } from '@aws-sdk/lib-dynamodb';

const dynamo = DynamoDBDocument.from(new DynamoDB());

export const handler = async (event) => {
    let body;
    let statusCode = '200';
    const headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
    };

    try {
        switch (event.httpMethod) {
            case 'GET':
                const email = event.queryStringParameters?.email;
                if (email) {
                    // GSI에서 email을 기준으로 최신 항목 가져오기
                    const params = {
                        TableName: "hama-web-Dynamo",
                        IndexName: "UserData-email-index",  // GSI 이름 명시
                        KeyConditionExpression: "email = :email",
                        ExpressionAttributeValues: {
                            ":email": email
                        },
                        ScanIndexForward: false,  // 최신 항목을 먼저 가져오기 위해 역순으로 스캔
                        Limit: 1  // 최신 항목 1개만 가져옴
                    };

                    const result = await dynamo.query(params);
                    if (result.Items && result.Items.length > 0) {
                        // 최신 article_id 값도 반환
                        body = {
                            article_id: result.Items[0].article_id,  // article_id 추가
                            minecraft_username: result.Items[0].minecraft_username,  // 마인크래프트 Username 추가
                            profileImageUrl: result.Items[0].profileImageUrl || "<https://s3.ap-northeast-2.amazonaws.com/hama-bulletin/User_Data/no_email/no_profile_image.png>",
                            profilecoment: result.Items[0].profilecoment || "No comment available."
                        };
                    } else {
                        // 기본 이미지와 기본 코멘트 설정
                        body = {
                            article_id: null,
                            profileImageUrl: "<https://s3.ap-northeast-2.amazonaws.com/hama-bulletin/User_Data/no_email/no_profile_image.png>",
                            profilecoment: "No comment available."
                        };
                    }
                } else {
                    throw new Error("Missing email parameter in GET request");
                }
                break;


            case 'PUT':
                // article_id를 기준으로 프로필 정보 업데이트
                const updateData = JSON.parse(event.body);
                if (!updateData.article_id) {
                    throw new Error("Missing article_id parameter in PUT request");
                }

                const updateParams = {
                    TableName: "hama-web-Dynamo",
                    Key: { 'article_id': updateData.article_id },  // article_id로 항목 식별
                    UpdateExpression: "set profileImageUrl = :p, profilecoment = :c, minecraft_username = :u",  // Minecraft Username 추가
                    ExpressionAttributeValues: {
                        ":p": updateData.profileImageUrl,
                        ":c": updateData.profilecoment,
                        ":u": updateData.minecraft_username
                    },
                    ReturnValues: "ALL_NEW"
                };
                body = await dynamo.update(updateParams);
                break;


            case 'DELETE':
                const deleteEmail = JSON.parse(event.body).email;
                if (deleteEmail) {
                    // 특정 email 항목 삭제
                    body = await dynamo.delete({
                        TableName: "hama-web-Dynamo",
                        Key: { 'email': deleteEmail }
                    });
                } else {
                    throw new Error("Missing email parameter in DELETE request");
                }
                break;

            default:
                throw new Error(`Unsupported method "${event.httpMethod}"`);
        }
    } catch (err) {
        statusCode = '400';
        body = err.message;
    } finally {
        body = JSON.stringify(body);
    }

    return {
        statusCode,
        body,
        headers,
    };
};
