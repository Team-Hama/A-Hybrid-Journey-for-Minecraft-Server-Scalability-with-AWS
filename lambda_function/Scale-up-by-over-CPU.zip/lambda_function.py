import os
import subprocess
import re


def lambda_handler(event, context):
    repo_url = "https://github.com/shlim0118/hama-deployment.git"
    repo_dir = '/tmp/repo'
    token = os.getenv('GITHUB_TOKEN')  # GitHub Personal Access Token

    # /tmp/repo 디렉토리가 존재하면 삭제
    if os.path.exists(repo_dir):
        subprocess.run(['rm', '-rf', repo_dir], check=True)

    # GitHub Personal Access Token을 포함한 리포지토리 URL
    repo_url_with_token = repo_url.replace("https://", f"https://{token}@")

    # 리포지토리 클론
    subprocess.run(['git', 'clone', repo_url_with_token, repo_dir], check=True)

    # velocity-onprem.yaml 파일 경로 설정
    file_path = os.path.join(repo_dir, 'velocity-onprem', 'velocity-onprem.yaml')
    
    # 파일 내용 읽기
    with open(file_path, 'r') as file:
        lines = file.readlines()

    # replicas 값 수정
    with open(file_path, 'w') as file:
        for line in lines:
            # 정확하게 'replicas: <숫자>' 찾고, 숫자를 2으로 변경
            modified_line = re.sub(r'(replicas:\s*)\d+', r'\g<1>' + '2', line)
            file.write(modified_line)

    # Git 사용자 정보 설정 (로컬로 설정)
    subprocess.run(['git', 'config', 'user.email', 'tim02366@naver.com'], cwd=repo_dir, check=True)
    subprocess.run(['git', 'config', 'user.name', 'Your Name'], cwd=repo_dir, check=True)
    
    # Git 커밋 및 푸시
    subprocess.run(['git', 'add', file_path], cwd=repo_dir, check=True)
    subprocess.run(['git', 'commit', '-m', 'Lambda에서 replicas 값을 2으로 수정'], cwd=repo_dir, check=True)
    subprocess.run(['git', 'push'], cwd=repo_dir, check=True)

    return {
        'statusCode': 200,
        'body': 'replicas 값을 2으로 수정하고 푸시 완료'
    }
