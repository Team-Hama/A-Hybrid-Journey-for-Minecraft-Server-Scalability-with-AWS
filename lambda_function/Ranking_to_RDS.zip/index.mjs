import mysql from 'mysql2/promise';

// RDS MySQL 연결 설정 (환경 변수 사용)
const pool = mysql.createPool({
    host: process.env.RDS_HOST,
    user: process.env.RDS_USER,
    password: process.env.RDS_PASSWORD,
    database: process.env.RDS_DATABASE
});

export const handler = async (event, context) => {
    const query = "SELECT * FROM xconomy ORDER BY balance DESC LIMIT 10";  // 쿼리문 작성

    try {
        const connection = await pool.getConnection();
        const [results] = await connection.query(query);  // MySQL 쿼리 실행
        connection.release();  // 연결 해제
        
        const response = {
            statusCode: 200,
            headers: {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",  // CORS 허용 헤더 추가
                "Access-Control-Allow-Methods": "GET",  // 허용할 HTTP 메서드
                "Access-Control-Allow-Headers": "Content-Type"  // 허용할 헤더
            },
            body: JSON.stringify(results)  // 결과를 JSON 형식으로 변환
        };

        return response;

    } catch (error) {
        console.error('Error executing query:', error);

        return {
            statusCode: 500,
            headers: {
                "Access-Control-Allow-Origin": "*",  // 오류 응답에도 CORS 허용 헤더 추가
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                error: 'Failed to fetch data'
            })
        };
    }
};
